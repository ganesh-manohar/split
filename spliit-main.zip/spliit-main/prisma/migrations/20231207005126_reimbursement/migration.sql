-- AlterTable
ALTER TABLE "Expense" ADD COLUMN     "isReimbursement" BOOLEAN NOT NULL DEFAULT false;
