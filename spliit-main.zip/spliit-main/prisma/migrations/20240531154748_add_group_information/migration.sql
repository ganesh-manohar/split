-- AlterTable
ALTER TABLE "Group" ADD COLUMN     "information" TEXT;
