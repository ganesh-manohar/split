-- AlterTable
ALTER TABLE "Expense" ADD COLUMN     "notes" TEXT;
