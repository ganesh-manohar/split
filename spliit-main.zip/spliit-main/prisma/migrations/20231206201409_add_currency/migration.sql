-- AlterTable
ALTER TABLE "Group" ADD COLUMN     "currency" TEXT NOT NULL DEFAULT '$';
