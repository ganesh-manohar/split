INSERT INTO "Category" ("id", "grouping", "name") VALUES (43, 'Life', 'Donation');
